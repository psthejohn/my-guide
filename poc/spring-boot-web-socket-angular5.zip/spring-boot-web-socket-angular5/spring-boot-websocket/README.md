## Description

add the websocket dependency first

`org.springframework.boot`

`spring-boot-starter-websocket`

## Setup and configurations

`mvn clean compile package`
and then 
`mvn spring-boot:run`

https://medium.com/oril/spring-boot-websockets-angular-5-f2f4b1c14cee
