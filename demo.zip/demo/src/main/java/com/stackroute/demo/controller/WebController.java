package com.stackroute.demo.controller;

import com.stackroute.demo.domain.Code;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.handler.annotation.MessageExceptionHandler;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;




@RestController
@CrossOrigin(value = "*")
public class WebController {

    @Autowired
    private SimpMessagingTemplate template;

   // endpoint for acccepting the messages coming from frontend and will send them back to topic "/chat"
    @MessageExceptionHandler
    @MessageMapping("/hello")
    public void onReceiveMessage(String message) throws Exception {
        System.out.println("data incoming is " + message);
        this.template.convertAndSend("/topic",new Code(message));
    }

    @GetMapping(value = "/hi")
    public void   hello(){
        System.out.println("hellojdfnvjfsdnvjsdjbl");
        //return "helllllllooooooo";
    }
}
